import { Box, Container, Typography } from "@mui/material";
import React from "react";

const About = () => {
  return (
    <Box
      id="about"
      sx={{
        // bgcolor: "#fff",
        display: "flex",
        flexDirection: "column",
        minHeight: "70vh",
      }}
    >
      <Container maxWidth="xl">
        <Typography
          sx={{ color: "primary.main", mx: 2, p: 2, textAlign: "center" }}
          variant="h4" 
        >
          About Us
        </Typography>

        <Typography
          sx={{ mx: 2, p: 2, mb: 4, textAlign: "justify" }}
          variant="body1"
        >
          Welcome to our AI, NLP, and Image Processing Training Hub! 🚀 Our
          Story At our institute, we’re passionate about empowering learners
          with cutting-edge knowledge in artificial intelligence (AI), natural
          language processing (NLP), and image processing. Our journey began
          when a team of seasoned professionals—comprising PhD faculty and
          real-world experts—came together to bridge the gap between theory and
          practical application. <br />
          <br />
          <Typography sx={{ mx: 2, p: 2, textAlign: "center" }} variant="h6">
            What Sets Us Apart
          </Typography>
          <br />
          Expert Faculty: Our instructors hold advanced degrees and have
          hands-on experience in their respective fields. They’re not just
          educators; they’re practitioners who’ve solved real-world challenges
          using AI, NLP, and image processing.
          <br />
          Real-World Projects: We believe in learning by doing. That’s why our
          curriculum emphasizes hands-on projects, where you’ll tackle
          real-world problems and build practical skills.
          <br />
          Community: Join a vibrant community of learners, where you can
          collaborate, network, and exchange ideas. Learning is more fun when
          you’re part of a supportive group!
          <br />
          <br />
        </Typography>
      </Container>
    </Box>
  );
};

export default About;
