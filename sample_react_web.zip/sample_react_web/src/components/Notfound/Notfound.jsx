import { Box, Container, Button, Typography } from "@mui/material";
import HomeIcon from "@mui/icons-material/Home";
import React from "react";
import { Link } from "react-router-dom";

const Notfound = () => {
  return (
    <Box
      id="Notfound"
      sx={{
        bgcolor: "#fff",
        color: "primary.main",
        p: 2,
        mb: 2,
      }}
    >
      <Container maxWidth="xl">
        <Box
          component="img"
          sx={{
            height: 350,
            width: 450,
            maxHeight: { xs: 233, md: 300 },
            maxWidth: { xs: 250, md: 400 },
            mx: "auto",
          }}
          src="https://i.ibb.co/9Zr4rwK/image.png"
          alt="404 image"
        />
        <Typography sx={{ mx: "auto", my: 2 }}>
          404 Page is not found Please check the url
        </Typography>

        <Button
          variant="contained"
          startIcon={<HomeIcon />}
          to="/"
          component={Link}
          sx={{ my: 2 }}
        >
          Back to Home
        </Button>
      </Container>
    </Box>
  );
};

export default Notfound;
