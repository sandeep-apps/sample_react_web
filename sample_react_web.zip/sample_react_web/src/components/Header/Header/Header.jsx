import React, { useState } from "react";
import {
  AppBar,
  Box,
  Container,
  Toolbar,
  Typography,
  IconButton,
  Menu,
  MenuItem,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import { HashLink } from "react-router-hash-link";

const Header = () => {
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="fixed" color="primary" sx={{ top: 0, bottom: "auto" }}>
        <Container maxWidth="xl">
          <Toolbar disableGutters>
            {/* Logo or title */}
            <Typography
              variant="h6"
              noWrap
              flexGrow={1}
              component="a"
              href="/"
              sx={{
                mr: 2,
                display: { xs: "none", md: "flex" },
                fontFamily: "monospace",
                fontWeight: "bold",
                color: "white",
                textDecoration: "none",
                alignItems: "center",
                gap: 1,
              }}
            >
              <img
                src="src/assets/logo-YTPL.png"
                alt="logo"
                width={50}
                height={50}
              />
              YANTRISIKSHA TECHNOLOGIES PRIVATE LIMITED
            </Typography>

            {/* Desktop menu */}
            <Box sx={{ display: { xs: "none", md: "flex" } }}>
              <HashLink
                to="/"
                style={{
                  textDecoration: "none",
                  color: "inherit",
                  marginRight: 16,
                }}
              >
                <Typography variant="h6" noWrap>
                  Home
                </Typography>
              </HashLink>
              <HashLink
                to="/about"
                style={{
                  textDecoration: "none",
                  color: "inherit",
                  marginRight: 16,
                }}
              >
                <Typography variant="h6" noWrap>
                  About
                </Typography>
              </HashLink>
              <HashLink
                to="/courses"
                style={{
                  textDecoration: "none",
                  color: "inherit",
                  marginRight: 16,
                }}
              >
                <Typography variant="h6" noWrap>
                  Courses
                </Typography>
              </HashLink>
              <HashLink
                to="/products"
                style={{ textDecoration: "none", color: "inherit" }}
              >
                <Typography variant="h6" noWrap>
                  Our Products
                </Typography>
              </HashLink>
            </Box>
            {/* Mobile menu button */}
            <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}>
              <IconButton
                size="large"
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleClick}
                color="inherit"
              >
                <MenuIcon />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={anchorEl}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={open}
                onClose={handleClose}
                sx={{ display: { xs: "block", md: "none" } }}
              >
                <MenuItem onClick={handleClose}>
                  <HashLink
                    to="/"
                    style={{ textDecoration: "none", color: "inherit" }}
                  >
                    <Typography variant="h6" noWrap>
                      Home
                    </Typography>
                  </HashLink>
                </MenuItem>
                <MenuItem onClick={handleClose}>
                  <HashLink
                    to="/about"
                    style={{ textDecoration: "none", color: "inherit" }}
                  >
                    <Typography variant="h6" noWrap>
                      About
                    </Typography>
                  </HashLink>
                </MenuItem>
                <MenuItem onClick={handleClose}>
                  <HashLink
                    to="/courses"
                    style={{ textDecoration: "none", color: "inherit" }}
                  >
                    <Typography variant="h6" noWrap>
                      Courses
                    </Typography>
                  </HashLink>
                </MenuItem>
              </Menu>
            </Box>
          </Toolbar>
        </Container>
      </AppBar>
    </Box>
  );
};

export default Header;
