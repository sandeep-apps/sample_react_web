import React from "react";
import {
  Avatar,
  Box,
  Chip,
  Container,
  Divider,
  Grid,
  Stack,
  styled,
  Typography,
} from "@mui/material";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import EmailIcon from "@mui/icons-material/Email";
import SchoolIcon from "@mui/icons-material/School";
import CallIcon from "@mui/icons-material/Call";
import FacebookIcon from "@mui/icons-material/Facebook";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import GitHubIcon from "@mui/icons-material/GitHub";
import { lightBlue } from "@mui/material/colors";
import { HashLink } from "react-router-hash-link";
import { useTheme } from "@mui/material/styles";

const Root = styled("div")(({ theme }) => ({
  // width: "100%",
  ...theme.typography.body2,
  "& > :not(style) + :not(style)": {
    marginTop: theme.spacing(2),
  },
}));

const Copyright = () => {
  return (
    <Typography variant="body2" color="white" align="center">
      {"Copyright "}
      <HashLink className="text-style" to="/home" color="white">
        YantriSiksha Technologies Pvt Ltd
      </HashLink>{" "}
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
};

const Footer = () => {
  const theme = useTheme();
  return (
    <footer>
      <Box
        className="sticky-container"
        sx={{
          bgcolor: "#000",
          color: "text.secondary",
          p: 2,
          top: "auto",
        }}
      >
        <Container maxWidth="xl">
          <Grid
            container
            spacing={{ xs: 2, md: 3 }}
            columns={{ xs: 4, sm: 8, md: 12 }}
          >
            <Grid sx={{ m: "auto" }} item xs={12} sm={6} md={4}>
              <Box>
                <Typography
                  variant="h6"
                  component="div"
                  direction="row"
                  justifyContent="flex-start"
                  alignItems="center"
                  sx={{
                    color: "white",
                    mr: 2,
                    display: { xs: "flex", md: "flex" },
                  }}
                >
                  <Avatar sx={{ mt: 1, mb: 1, mr: 1, bgcolor: "white" }}>
                    <SchoolIcon color="primary" fontSize="large" />
                  </Avatar>
                  YantriSiksha Technologies Pvt Ltd{" "}
                </Typography>
                <Divider />
              </Box>

              <Stack
                direction="row"
                justifyContent="flex-start"
                alignItems="center"
                spacing={1}
              >
                <Avatar sx={{ mt: 1, bgcolor: lightBlue[500] }}>
                  <LocationOnIcon />
                </Avatar>
                <Typography color="white">
                  Siddhartha enclave, Navodaya co, Tadepalli, Guntur, AP 522501
                </Typography>
              </Stack>

              <Stack
                direction="row"
                justifyContent="flex-start"
                alignItems="center"
                spacing={1}
              >
                <Avatar sx={{ my: 1, bgcolor: lightBlue[500] }}>
                  <EmailIcon />
                </Avatar>
                <Stack>
                  <a
                    className="text-style"
                    href="mailto:yst.director1@yantrisiksha.in"
                  >
                    yst.director1@yantrisiksha.in
                  </a>
                  <a
                    className="text-style"
                    href="mailto:yst.director2@yantrisiksha.in"
                  >
                    yst.director2@yantrisiksha.in
                  </a>
                </Stack>
              </Stack>

              <Stack
                direction="row"
                justifyContent="flex-start"
                alignItems="center"
                spacing={1}
              >
                <Avatar sx={{ mb: 1, bgcolor: lightBlue[500] }}>
                  <CallIcon />
                </Avatar>
                <a className="text-style" href="tel:91680xxx86">
                  91680xxx86
                </a>
              </Stack>
            </Grid>

            <Grid item xs={12} sm={4}>
              <Chip
                sx={{ bgcolor: "white", my: 2 }}
                label="Find us on social media"
              />

              <Stack
                direction="row"
                justifyContent="flex-start"
                alignItems="center"
                spacing={1}
                my={1}
              >
                <Avatar sx={{ mb: 1, bgcolor: lightBlue[500] }}>
                  <LinkedInIcon />
                </Avatar>
                <a
                  className="text-style"
                  href="https://www.linkedin.com/in/YantriSiksha/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  YantriSiksha on LinkedIn
                </a>
              </Stack>

              <Stack
                direction="row"
                justifyContent="flex-start"
                alignItems="center"
                spacing={1}
              >
                <Avatar sx={{ mb: 1, bgcolor: lightBlue[500] }}>
                  <GitHubIcon />
                </Avatar>
                <a
                  className="text-style"
                  href="https://github.com/YantriSiksha"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  YantriSiksha on GitHub
                </a>
              </Stack>
            </Grid>
          </Grid>
          <Divider sx={{ mb: 2 }} />
          <Copyright sx={{ mt: 5 }} />
        </Container>
      </Box>
    </footer>
  );
};

export default Footer;
