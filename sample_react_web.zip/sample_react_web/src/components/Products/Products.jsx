import React from "react";
import { Box, Container, Typography } from "@mui/material";
import Carousel from "react-material-ui-carousel";

const Products = () => {
  return (
    <Box id="Products" sx={{ display: "flex", flexDirection: "column", my: 2 }}>
      <Container maxWidth="xl">
        <Typography
          sx={{ mt: 8, mb: 2, fontWeight: 600, textAlign: "center" }}
          variant="h4"
        >
          Our Products
        </Typography>
        <Carousel>
          <Box>
            <Typography
              sx={{ my: 1, color: "primary.main", textAlign: "center" }}
              variant="h5"
            >
              Smart Security Guard (SSG)
            </Typography>
            <Typography
              gutterBottom
              component="div"
              sx={{ textAlign: "center" }}
            >
              The Smart Security Guard (SSG) project aims to develop AI-powered
              real-time systems, bringing cloud-based AI operations to the edge.
              It focuses on applying deep learning skills to real-world
              applications and creating an AI workspace for local communities.
              The project will use hardware for human pose estimation, face
              recognition, crime monitoring, person reidentification, emergency
              management, crowd sensing, theft alarms, and fire detection.
              Ultimately, it will transform basic computing systems into
              AI-powered hardware.
            </Typography>
          </Box>
          <Box>
            <Typography
              sx={{ my: 1, color: "primary.main", textAlign: "center" }}
              variant="h5"
            >
              Pipeline Exterior Damage Detector (PEDD)
            </Typography>
            <Typography
              gutterBottom
              component="div"
              sx={{ textAlign: "center" }}
            >
              The PED² system protects underground pipelines carrying hazardous
              materials from damage due to digging. It uses underground
              vibration sensors placed every 1 km with a 5-meter resolution,
              combined with an AI detection system to identify ground movement.
              Each sensor has a GPS for location mapping. The system
              continuously monitors signals through a machine learning model to
              detect true and false digging activities, alerting nearby
              engineers or watchmen to prevent intrusions.
            </Typography>
          </Box>
          <Box>
            <Typography
              sx={{ my: 1, color: "primary.main", textAlign: "center" }}
              variant="h5"
            >
              Hasth Chihan Bhasha
            </Typography>
            <Typography
              gutterBottom
              component="div"
              sx={{ textAlign: "center" }}
            >
              The first product is a web and mobile-based Indian sign language
              translator that facilitates communication between hearing-impaired
              and normal individuals. Over 10% of the global population
              experiences hearing loss, and while hearing devices are advanced,
              they have limitations. Sign language is a convenient solution, but
              it poses a learning challenge for those with normal hearing.
              Hearing loss can lead to socio-economic challenges for the
              affected individuals.
            </Typography>
          </Box>
        </Carousel>
      </Container>
    </Box>
  );
};

export default Products;
