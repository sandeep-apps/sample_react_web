import { Box, Container, Typography, Divider } from "@mui/material";
import React from "react";

const OurProducts = () => {
  return (
    <Box
      id="OurProducts"
      sx={{
        display: "flex",
        flexDirection: "column",
        minHeight: "100vh",
        bgcolor: "#fff",
        color: "primary.main",
        p: 2,
        mb: 2,
      }}
    >
      <Container maxWidth="xl">
        <Typography
          sx={{ mt: 8, mb: 2, fontWeight: 600, textAlign: "center" }}
          variant="h4"
        >
          Our Products
        </Typography>
        <Typography sx={{ my: 1, color: "primary.main" }} variant="h5">
          Smart Security Guard(SSG)
        </Typography>
        <Typography
          gutterBottom
          variant="body2"
          color="text.secondary"
          component="div"
        >
          The objective of this project smart security guard (SSG) is to
          transform the knowledge gained over the years into development of AI
          powered real time systems. In other words, the project will help in
          bring the current cloud-based AI operations to the edge of the digital
          ecosystem. This platform will enable us to learn and apply the skills
          of deep learning as real world applications. Subsequently, this
          project will help in instigating an AI workspace in the society for
          generating powerful resources to local communities. The hardware
          procured in this project will be used for developing a Human pose
          estimation, Face recognition system for identifying person with
          criminal record, Monitoring of actions to decrease crime, person
          reidentification, Emergency situation management, Crowd sensing, Theft
          alarm systems and Fire detection in open fields. in closed loop
          surveillance models. Finally, this project will identify the
          procedures to transform a basic computing system into an AI powered
          hardware system.
          <br />
          <img
            src="src/assets/comp vision.png"
            alt="logo"
            style={{ maxWidth: "100%", height: "auto" }}
          />
          <Divider />
          <br />
          <Typography sx={{ my: 1, color: "primary.main" }} variant="h5">
            Pipeline Exterior Damage Detector (PEDD): A wireless under Ground
            Motion Sensor Network with AI{" "}
          </Typography>
          <Typography
            gutterBottom
            variant="body2"
            color="text.secondary"
            component="div"
          >
            The PED² protects the underground pipes carrying hazardous materials
            from external damages caused by intentional or accidental digging in
            the vicinity of the pipeline. The system is a combination of
            underground vibration sensors around the pipeline as a sensing
            system and an AI based detection system to identify ground movement
            around the pipeline. The vibration sensors are placed at every 1km
            with a spatial resolution of 5 meters. Each sensor is associated
            with a GPS device for location mapping function. The sensor network
            contineously outputs the signal which is monitored through a machine
            learning model that has learned to classify sensors signals for true
            and false digging detection near to the pipeline. The AI interface
            will thereby alerts the nearest engineers or a local watchman to
            stop the intrusion.{" "}
          </Typography>
          <br />
          <img
            src="src/assets/sensor.jfif"
            alt="logo"
            style={{ maxWidth: "100%", height: "auto" }}
          />
          <Divider />
          <br />
          <Typography sx={{ my: 1, color: "primary.main" }} variant="h5">
            Hasth Chihan Bhasha
          </Typography>
        </Typography>
        <Typography
          gutterBottom
          variant="body2"
          color="text.secondary"
          component="div"
        >
          The first product is web and mobile based Indian sign language
          translator that serves as a communication medium between the hearing
          impaired and normal persons. Admittedly more than 10% of the world
          population suffers from some kind of hearing loss and the quality of
          hearing devices, though exceptionally high are limited in their
          performance on instances of hard hearing problems. The most convenient
          solution is the sign language that comes with a problem of learning by
          normal human with sensitivity towards sound. Eventually the loss of
          hearing sensitivity has underlying implications in the form of Scio
          economic crisis on the lives of hearing impaired.
        </Typography>
        <br />
        <img
          src="src/assets/hasth.jpg"
          alt="logo"
          style={{ maxWidth: "100%", height: "auto" }}
        />
        <Divider />
      </Container>
    </Box>
  );
};

export default OurProducts;
