import React from "react";
import About from "../About/About";
import Banner from "./Banner/Banner";
import "./Home.css";
import OurExperts from "./OurExperts/OurExperts";
import Whyus from "./Whyus/Whyus";
import swal from "sweetalert";
import Products from "../Products/Products";

const Home = () => {
  //swal alert
  const mailSendBtn = () => {
    swal(
      "WOW!! Your subscription is done you will get update when we setup our mail server",
      {
        button: false,
        icon: "success",
      }
    );
  };
  return (
    <div id="home">
      <Banner />
      <Whyus />
      <About />
      <OurExperts />
      <Products />
    </div>
  );
};

export default Home;
