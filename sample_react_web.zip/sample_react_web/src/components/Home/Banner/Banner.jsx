import { Paper, Typography } from "@mui/material";
import React from "react";
import Carousel from "react-material-ui-carousel";
import "./Banner.css";

const Banner = () => {
  function Item(props) {
    return (
      <Paper>
        <div className="banner-container">
          <img src={props.item.img} alt="" />
          <div className="banner-text tracking-in-expand">
            <Typography component="h4" variant="h5">
              {props.item.name}
            </Typography>
            <Typography component="p">{props.item.description}</Typography>
          </div>
        </div>
      </Paper>
    );
  }
  const items = [
    {
      name: "You are just one click away from AI learning",
      description: "Probably the most exciting thing you have ever seen!",
      img: "src/assets/IMG-20240726-WA0051.jpg",
    },
    {
      name: "Consult with expert faculty for guide",
      description: "Get Online enquiry from our expert faculty within 24/7",
      img: "src/assets/IMG-20240726-WA0040.jpg",
    },
    {
      name: "Check our courses for more details",
      description: "Upto date with latest AI/ML field developments",
      img: "src/assets/IMG-20240726-WA0039.jpg",
    },
  ];
  return (
    <div>
      <Carousel>
        {items.map((item, i) => (
          <Item key={i} item={item} />
        ))}
      </Carousel>
    </div>
  );
};

export default Banner;
