import {
  Box,
  Avatar,
  Card,
  CardActionArea,
  CardContent,
  Container,
  Grid,
  LinearProgress,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { HashLink } from "react-router-hash-link";
import useTutorsData from "../../../Hooks/useTutorsData";

const OurExperts = () => {
  const [ourExperts, setOurExperts] = useState([]);
  const mainData = useTutorsData();
  let experts = mainData[0];

  // handle undifined problem in mapping data
  useEffect(() => {
    if (experts.length > 1) {
      const serv = experts?.slice(0, 3);
      setOurExperts(serv);
    } else {
      <LinearProgress color="secondary" />;
    }
  }, [experts]);

  return (
    <Box
      sx={{
        bgcolor: "#fff",
        color: "primary.main",
        p: 2,
        mb: 2,
        textAlign: "center",
      }}
    >
      <Container maxWidth="xl">
        <Typography sx={{ my: 2 }} variant="h4">
          Meet Our Expert Team
        </Typography>

        <Typography sx={{ mb: 4 }} variant="h5">
          We are committed to ensure you the best training
        </Typography>

        {experts?.length > 1 && (
          <Grid container spacing={3}>
            {ourExperts?.map((experts) => (
              <Grid
                key={experts.id}
                item
                xs={12}
                sm={6}
                md={4}
                lg={3}
                sx={{ mx: "auto" }}
              >
                <Card
                  sx={{
                    maxWidth: 345,
                    transition: "0.5s all ease-in-out",
                    mb: 2,
                    ":hover": {
                      boxShadow: 10,
                      // color: "#e91e63",
                      color: "#1976d2",
                    },
                    img: { transition: "0.5s all ease-in-out" },
                    ":hover img": {
                      transform: "scale(1.1)",
                    },
                  }}
                >
                  <CardActionArea>
                    <Avatar
                      alt="Tutor image"
                      src={experts?.tutor_img}
                      sx={{
                        width: 256,
                        height: 256,
                        mx: "auto",
                      }}
                    />

                    <CardContent>
                      <Typography gutterBottom variant="h5" component="div">
                        {experts.specialize}
                      </Typography>
                    </CardContent>
                    <Typography gutterBottom variant="h6" component="div">
                      Dr. {experts.name}
                    </Typography>
                  </CardActionArea>
                </Card>
              </Grid>
            ))}
          </Grid>
        )}
      </Container>
    </Box>
  );
};

export default OurExperts;
