import {
  Avatar,
  Box,
  Card,
  CardActionArea,
  CardActions,
  CardContent,
  CardMedia,
  Container,
  Grid,
  LinearProgress,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { HashLink } from "react-router-hash-link";
import useData from "../../../Hooks/useData";
import "./Whyus.css";

const Whyus = () => {
  const [ourCourses, setOurCourses] = useState([]);
  const mainData = useData();
  let courses = mainData[0];

  // handle undefined problem in mapping data
  useEffect(() => {
    if (courses.length > 1) {
      const cour = courses?.slice(0, 3);
      setOurCourses(cour);
    } else {
      <LinearProgress color="secondary" />;
    }
  }, [courses]);

  return (
    <Box
      sx={{
        bgcolor: "#fff",
        color: "primary.main",
        p: 2,
        mb: 2,
        textAlign: "center",
      }}
    >
      <Container maxWidth="xl">
        <Typography sx={{ m: 2 }} variant="h4">
          Our Courses
        </Typography>

        <Typography sx={{ mb: 4 }} variant="h5">
          Comprehensive, Practical and Job oriented
        </Typography>

        {courses?.length > 1 && (
          <Grid container spacing={3}>
            {ourCourses?.map((course) => (
              <Grid
                key={course.id}
                className={course.class}
                item
                xs={12}
                md={6}
                lg={4}
              >
                <Card
                  sx={{
                    maxWidth: 345,
                    transition: "0.5s all ease-in-out",
                    mb: 2,
                    ":hover": {
                      boxShadow: 10,
                      // color: "#e91e63",
                      color: "#1976d2",
                    },
                    img: { transition: "0.5s all ease-in-out" },
                    ":hover img": {
                      transform: "scale(1.1)",
                    },
                  }}
                >
                  <CardActionArea>
                    <CardMedia
                      component="img"
                      height="240"
                      image={course?.course_img}
                      alt="card image of course"
                    />
                    <CardContent sx={{ display: "flex", mx: "auto" }}>
                      <Typography gutterBottom variant="h5" component="div">
                        {course.course}
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                  <CardActions>
                    <Typography sx={{ mx: 2, p: 0.5, textAlign: "end" }}>
                      <Link
                        className="text-style"
                        to={`/courses/${course?.id}`}
                        color="primary"
                      >
                        See More Details...
                      </Link>
                    </Typography>
                  </CardActions>
                </Card>
              </Grid>
            ))}
          </Grid>
        )}

        <Typography sx={{ mx: 2, p: 2, textAlign: "end" }}>
          <HashLink
            smooth
            to="/courses#courses"
            className="text-style"
            color="primary"
          >
            See All courses
          </HashLink>
        </Typography>
      </Container>
    </Box>
  );
};

export default Whyus;
