import { useNavigate } from "react-router-dom";
import {
  Box,
  Button,
  Card,
  CardActionArea,
  CardActions,
  CardContent,
  CardMedia,
  CircularProgress,
  Container,
  Grid,
  Typography,
} from "@mui/material";
import useData from "../../Hooks/useData";
import ReadMoreIcon from "@mui/icons-material/ReadMore";
import { useEffect, useState } from "react";

const Courses = () => {
  const [ourCourses, setOurCourses] = useState([]);
  const mainData = useData();
  let courses = mainData[0];

  // handle undefined problem in mapping data
  useEffect(() => {
    if (courses.length > 1) {
      const cour = courses?.slice(0, 3);
      setOurCourses(cour);
    }
  }, [courses]);

  const navigate = useNavigate();

  const handleCourseDetails = (courseId) => {
    navigate(`/courses/${courseId}`);
  };
  return (
    <Box
      id="Course"
      sx={{
        display: "flex",
        flexDirection: "column",
        minHeight: "100vh",
        bgcolor: "#fff",
        color: "primary.main",
        p: 2,
        mb: 2,
        textAlign: "center",
      }}
    >
      {courses?.length > 1 ? (
        <Container maxWidth="xl">
          <Typography sx={{ mt: 8, mb: 2, fontWeight: 600 }} variant="h4">
            Our Courses
          </Typography>
          <Grid container key={1} spacing={3}>
            {ourCourses?.map((course) => (
              <Grid key={course.id} item xs={12} sm={6} md={6} lg={4}>
                <Card
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    mx: "auto",
                    height: "100%",
                    transition: "0.5s all ease-in-out",
                    ":hover": {
                      boxShadow: 10,
                      // color: "#e91e63",
                      color: "#1976d2",
                    },
                    img: { transition: "0.5s all ease-in-out" },
                    ":hover img": { transform: "scale(1.1)" },
                  }}
                >
                  <CardActionArea>
                    <CardMedia
                      component="img"
                      height="240"
                      image={course.course_img}
                      alt="card image of Course"
                    />
                    <CardContent
                      sx={{
                        display: "flex",
                        flexWrap: "wrap",
                        mx: "auto",
                        my: 2,
                      }}
                    >
                      <Typography
                        gutterBottom
                        variant="body2"
                        color="text.secondary"
                        component="div"
                      >
                        Consult for {course.description}
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                  <CardActions>
                    <Typography sx={{ p: 2 }}>
                      <Button
                        onClick={() => handleCourseDetails(course.id)}
                        variant="contained"
                        color="primary"
                        startIcon={<ReadMoreIcon />}
                      >
                        See More Details...
                      </Button>
                    </Typography>
                  </CardActions>
                </Card>
              </Grid>
            ))}
          </Grid>
          {/* <HashLink smooth to="/home#home" className="text-style">
            <Button
              variant="contained"
              color="primary"
              startIcon={<HomeIcon />}
              sx={{ mb: 5, mt: 5 }}
            >
              Back to Home
            </Button>
          </HashLink> */}
        </Container>
      ) : (
        <CircularProgress />
      )}
    </Box>
  );
};

export default Courses;
