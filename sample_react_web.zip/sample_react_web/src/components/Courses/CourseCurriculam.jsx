import {
  Box,
  Container,
  List,
  ListItem,
  ListItemText,
  Typography,
} from "@mui/material";
import { useParams } from "react-router-dom";
import useData from "../../Hooks/useData";

const CourseCurriculum = () => {
  const { id } = useParams();
  const mainData = useData();
  let courses = mainData[0];
  let selectedCourse = courses.find((course) => course.id == id);
  console.log(selectedCourse);
  console.log(id);
  if (!selectedCourse) {
    return (
      <Typography variant="h6" sx={{ mx: 5, p: 2, mb: 4, textAlign: "center" }}>
        Course not found
      </Typography>
    );
  }

  return (
    <Box
      id="course-curriculum"
      sx={{
        bgcolor: "#fff",
        display: "flex",
        flexDirection: "column",
        minHeight: "70vh",
      }}
    >
      {selectedCourse && (
        <Container maxWidth="xl">
          <Typography
            sx={{
              color: "primary.main",
              mt: 8,
              mx: 2,
              p: 2,
              fontWeight: 600,
              textAlign: "center",
            }}
            variant="h4"
          >
            Course Curriculum of {selectedCourse.course}
          </Typography>

          <List sx={{ m: 2, p: 2 }}>
            <ListItem>
              <ListItemText
                sx={{ color: "primary.main" }}
                primary="Description:"
                secondary={selectedCourse.description}
              />
            </ListItem>
            <ListItem>
              <ListItemText
                sx={{ color: "primary.main" }}
                primary="Price:"
                secondary={selectedCourse.price}
              />
            </ListItem>
            <ListItem>
              <ListItemText
                sx={{ color: "primary.main" }}
                primary="Mode of teaching:"
                secondary={selectedCourse.class}
              />
            </ListItem>
          </List>
        </Container>
      )}
    </Box>
  );
};

export default CourseCurriculum;
