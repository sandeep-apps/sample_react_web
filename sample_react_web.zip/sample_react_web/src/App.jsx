import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@mui/material";
import { createTheme } from "@mui/material/styles";
import Notfound from "./components/Notfound/Notfound.jsx";
import Footer from "./components/Header/Footer/Footer.jsx";
import Home from "./components/Home/Home.jsx";
import Header from "./components/Header/Header/Header.jsx";
import AboutUs from "./components/About/AboutUs.jsx";
import OurProducts from "./components/Products/OurProducts.jsx";
import Courses from "./components/Courses/Courses.jsx";
import CourseCurriculam from "./components/Courses/CourseCurriculam.jsx";

// custom style for this application
export const myTheme = createTheme({
  palette: {
    primary: {
      // main: "#e91e63",
      main: "#1976d2", // Blue
      // main: "#388e3c", // Green
      // main: "#d32f2f", // Red
    },
    secondary: {
      // main: "#f48fb1",
      main: "#9c27b0", // Purple
      // main: "#fbc02d", // Yellow
      // main: "#ff9800", // Orange
    },
    alternate: {
      // main: "#fce4ec",
      main: "#e3f2fd", // Light Blue
      // main: "#e8f5e9", // Light Green
      // main: "#ffebee", // Light Red
    },
  },
  typography: {
    fontFamily: "Quicksand",
    fontWeightLight: 400,
    fontWeightRegular: 500,
    fontWeightMedium: 600,
    fontWeightBold: 700,
  },
});

const App = () => {
  return (
    <ThemeProvider theme={myTheme}>
      <BrowserRouter>
        <Header />
        <Routes>
          <Route index element={<Home />} />
          <Route path="home" element={<Home />} />
          <Route path="about" element={<AboutUs />} />
          <Route path="courses" element={<Courses />} />
          <Route path="products" element={<OurProducts />} />
          <Route path="courses/:id" element={<CourseCurriculam />} />
          <Route path="*" element={<Notfound />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </ThemeProvider>
  );
};

export default App;
