import { useEffect, useState } from "react";

const useTutorsData = () => {
  const [tutorData, setTutorData] = useState([]);

  useEffect(() => {
    async function fetchData() {
      await fetch("../../fakedata/tutorsdb.json")
        .then((resp) => resp.json())
        .then((data) => setTutorData(data.tutors));
    }
    fetchData();
  }, []);

  return [tutorData];
};

export default useTutorsData;
